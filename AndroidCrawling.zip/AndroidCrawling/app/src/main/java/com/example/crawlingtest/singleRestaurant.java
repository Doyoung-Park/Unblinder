package com.example.crawlingtest;

public class singleRestaurant {
    String name;
    String mobile;


    public singleRestaurant(String name, String mobile) {
        this.mobile = mobile;
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getName() {
        return  name;
    }

    public String getMobile() {
        return mobile;
    }

    @Override
    public String toString() {
        return "이름 : " + name + "전화번호 : " + mobile;
    }
}
