package com.example.crawlingtest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.URL;


public class MainActivity extends AppCompatActivity {
    // 크롤링용 변수
    String keyword = "null";
    int action = -1;


    String total_restaurant = "";                    //

    TextView textView;
    String next_button = "spnew_bf cmm_pg_next on";
    String prev_button = "spnew_bf cmm_pg_prev";

    // 이미지 가져오기 파트
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.textView); // TextView textView = ~~ 식으로 하면 앱이 계속 꺼짐 ㄷㄷ
        // 여러 가지 타입의 데이터들을 String 형태의 Key 값과 함께 저장하는 Map 클래스
        final Bundle bundle1 = new Bundle(); // 메뉴 이름 스트링 전달용 번들

        Button button = findViewById(R.id.button);

        EditText editText = findViewById(R.id.editText);

        RadioGroup radioType = findViewById(R.id.radioType);
        RadioButton rad0 = findViewById(R.id.radio0);
        RadioButton rad1 = findViewById(R.id.radio1);
        RadioButton rad2 = findViewById(R.id.radio2);
        RadioButton rad3 = findViewById(R.id.radio3);

        Button button1 = findViewById(R.id.button2);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textView.setText("결과");
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                keyword = editText.getText().toString();

                int radioId = radioType.getCheckedRadioButtonId();
                if(rad0.getId()==radioId)
                    action = 0;
                if(rad1.getId()==radioId)
                    action = 1;
                if(rad2.getId()==radioId)
                    action = 2;
                if(rad3.getId()==radioId)
                    action = 3;

                new Thread() {
                    @Override

                    public void run() {
                        Document doc = null;

                        try {
                            if (action == 0) {
                                String url = "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=" + keyword;
                                doc = Jsoup.connect(url).get(); // 이 주소의 html코드를 싹 가져오겠다
                                Elements elements_name = doc.getElementsByAttributeValue("class", "OXiLu");

                                total_restaurant = total_restaurant.concat(Integer.toString(elements_name.size()));
                                for (int i = 0; i < elements_name.size(); i++) {
                                    total_restaurant = total_restaurant.concat(elements_name.get(i).toString());
                                }
                                bundle1.putString("restaurant", total_restaurant); // (key값, value값) 메뉴 이름
                                // 쓰레드 간의 데이터 전송을 위한 객체
                                Message msg1 = handler.obtainMessage();
                                msg1.setData(bundle1);
                                handler.sendMessage(msg1); //메뉴 이름 먼저 보내고~

                            }



                            if (action == 1) {
                                String url = "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=0&ie=utf8&query=" + keyword;
                                doc = Jsoup.connect(url).get(); // 이 주소의 html코드를 싹 가져오겠다


                                Elements phoneNumber = doc.select("._3HEBM");
                                if (phoneNumber.isEmpty()) phoneNumber = doc.select(".txt");

                                String phoneNum = phoneNumber.text();

                                bundle1.putString("restaurant", phoneNum); // (key값, value값) 메뉴 이름
                                // 쓰레드 간의 데이터 전송을 위한 객체
                                Message msg1 = handler.obtainMessage();
                                msg1.setData(bundle1);
                                handler.sendMessage(msg1); //메뉴 이름 먼저 보내고~

                            }

                            if (action == 2) {
                                textView.setText("action 2");
                            }

                            if (action == 3) {
                                textView.setText("action 3");
                            }


                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }


                }.start();
            }

        });







    }

    Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            Bundle bundle = msg.getData();
            if (action == 0) {
                String parsed_total_restaurant = bundle.getString("restaurant");

                String[] parsed_restaurant_list = stringcutter(parsed_total_restaurant);

                int restaurant_count = Integer.parseInt(parsed_restaurant_list[0]);

                String result = "";


                for (int i = 0; i < restaurant_count; i++) {
                    result = result.concat(parsed_restaurant_list[i]);
                }

                textView.setText(result);





            }
            else if (action == 1) {
                String information = bundle.getString("restaurant");

                textView.setText(information);
            }

        }
    };

    public String[] stringcutter(String message) {
        String[] list = message.split("<span class=\"OXiLu\">", 0);

        int size = Integer.parseInt(list[0]);

        String new_list[] = new String[size];

        new_list[0] = list[0];

        for (int i = 1; i < Integer.parseInt(list[0]); i++) {
            String[] each_list = list[i].split("</span>", 0);
            new_list[i] = each_list[0];
        }

        return new_list;
    }




}

